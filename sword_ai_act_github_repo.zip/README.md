# Sword EU AI Act – Workbook → Summary (POC)

Minimal, free, no-install **prototype** to turn the EU AI Act Excel workbook into a **summary report** (AI?/Role/Scope/Risk) and a **light obligations list**.

Works great on **Google Colab** or locally with Python.

## What's inside
- `ai_act_rules.py` → parses the workbook and applies the core IF/THEN rules from the Playbook (Wave 1 logic + tiny obligations map).
- `ai_act_summary_demo.ipynb` → notebook that loads the Excel, runs the rules, and exports `summary.csv`.
- `requirements.txt` → `pandas` + `openpyxl` (for local runs).

## Quick start (Colab, recommended)
1. Open Google Colab → **File ▸ Upload notebook** → select `ai_act_summary_demo.ipynb`.
2. Upload **your** workbook (`EU-AI-ACT_Playbook.xlsx` or similar) when prompted.
3. The notebook prints a **Summary table** and saves `summary.csv` you can download.

## Quick start (Local Python)
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -c "import ai_act_rules as r; import pandas as pd; s,o = r.summarize('EU-AI-ACT_Playbook.xlsx'); print(s.head())"
```

## Notes
- This is a **POC**: rules are implemented to be **robust to column names** (it searches by QID rows like `Q1.1`, `Q2.1.1`, etc.).
- If a question is missing or blank, the result will say `Unknown` and continue.
- You can extend `OBLIGATIONS_MAP` in `ai_act_rules.py` to reflect your Annex.
