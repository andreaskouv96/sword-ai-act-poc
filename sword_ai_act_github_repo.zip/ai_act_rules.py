
import pandas as pd
from typing import List, Tuple

OBLIGATIONS_MAP = {
    ("Provider", "High-Risk"): ["Risk Management System (Art.9)", "Data Governance (Art.10)", "Technical Documentation (Art.11)", "Human Oversight (Art.14)"],
    ("Deployer", "High-Risk"): ["Human Oversight & Logging (Art.26)", "FRIA (Art.27)", "AI Literacy & Transparency (Art.4, Art.50)"],
    ("Provider", "Limited"): ["Transparency (Art.50)"],
    ("Deployer", "Limited"): ["Transparency (Art.50)", "AI Literacy (Art.4)"],
}

def _system_columns(df: pd.DataFrame) -> List[int]:
    idxs = []
    for i, col in enumerate(df.columns):
        if isinstance(col, str) and col.strip().upper().startswith("SYSTEM"):
            idxs.append(i)
    return idxs

def _find_rows_by_qid(df: pd.DataFrame, qid: str) -> pd.DataFrame:
    mask = df.apply(lambda row: any(str(cell).strip() == qid for cell in row), axis=1)
    return df[mask]

def _get_answer(df: pd.DataFrame, qid: str, sys_col_idx: int) -> str:
    rows = _find_rows_by_qid(df, qid)
    if rows.empty:
        return ""
    row = rows.iloc[0]
    if sys_col_idx >= len(df.columns):
        return ""
    return str(row.iloc[sys_col_idx]).strip()

def _any_yes(df: pd.DataFrame, qids: List[str], sys_col_idx: int) -> bool:
    for q in qids:
        val = _get_answer(df, q, sys_col_idx).upper()
        if val in ["Y", "YES", "TRUE", "1"]:
            return True
    return False

def _role_from_q(df: pd.DataFrame, sys_col_idx: int) -> str:
    if _any_yes(df, ["Q2.1.1"], sys_col_idx): 
        return "Provider"
    base = "Unknown"
    if _any_yes(df, ["Q2.1.2"], sys_col_idx): base = "Deployer"
    elif _any_yes(df, ["Q2.1.3"], sys_col_idx): base = "Importer"
    elif _any_yes(df, ["Q2.1.4"], sys_col_idx): base = "Distributor"
    elif _any_yes(df, ["Q2.1.5"], sys_col_idx): base = "Authorised Representative"
    # promotion to Provider if Q2.2.x is Yes
    if base in ["Deployer", "Importer", "Distributor", "Authorised Representative"] and _any_yes(df, ["Q2.2.1", "Q2.2.2", "Q2.2.3"], sys_col_idx):
        return "Provider"
    return base

def _ai_flag(df: pd.DataFrame, sys_col_idx: int) -> str:
    return "Yes" if _any_yes(df, ["Q1.1", "Q1.2", "Q1.3", "Q1.4", "Q1.5"], sys_col_idx) else "No"

def _scope(df: pd.DataFrame, sys_col_idx: int) -> str:
    if _any_yes(df, ["Q3.1", "Q3.2", "Q3.3", "Q3.4"], sys_col_idx):
        return "Out of Scope"
    if _any_yes(df, ["Q3.5", "Q3.6", "Q3.7"], sys_col_idx):
        return "In Scope"
    return "Unknown"

def _risk(df: pd.DataFrame, sys_col_idx: int) -> str:
    if _any_yes(df, ["Q4.1", "Q4.2", "Q4.3", "Q4.4", "Q4.5", "Q4.6", "Q4.7", "Q4.8", "Q4.8.1"], sys_col_idx):
        return "Prohibited"
    high_ids = ["Q5.3", "Q5.3.1", "Q5.3.2", "Q5.3.3", "Q5.3.4", "Q5.3.5"]
    limited_ids = ["Q6.2", "Q6.3", "Q6.4", "Q6.5", "Q6.6", "Q6.6.1"]
    if _any_yes(df, high_ids, sys_col_idx):
        if _any_yes(df, ["Q5.4", "Q5.4.1", "Q5.4.2", "Q5.4.3", "Q5.4.4"], sys_col_idx):
            return "High-Risk (exemption applicable)"
        return "High-Risk"
    if _any_yes(df, limited_ids, sys_col_idx):
        return "Limited Risk"
    return "Minimal/Unknown"

def _system_names(df: pd.DataFrame, sys_idxs):
    names = []
    for idx in sys_idxs:
        # Q0.2 holds "System Name" in most versions
        name_candidates = ["Q0.2", "Q0.02", "Q0.2.0"]
        name = ""
        for qid in name_candidates:
            name = _get_answer(df, qid, idx)
            if name and name.lower() != "nan":
                break
        if not name or name.lower() == "nan":
            name = f"System #{len(names)+1}"
        names.append(name)
    return names

def summarize(xls_path_or_file) -> Tuple[pd.DataFrame, pd.DataFrame]:
    xls = pd.ExcelFile(xls_path_or_file)
    sysdesc = pd.read_excel(xls, "Systems Description", dtype=str)
    verify = pd.read_excel(xls, "Systems Verification", dtype=str)

    sys_cols = _system_columns(sysdesc)
    names = _system_names(sysdesc, sys_cols)

    rows = []
    obligations_rows = []

    for col_idx, sys_name in zip(sys_cols, names):
        ai = _ai_flag(verify, col_idx)
        role = _role_from_q(verify, col_idx)
        scope = _scope(verify, col_idx)
        risk = _risk(verify, col_idx)

        rows.append({"System": sys_name, "Is AI?": ai, "Entity Role": role, "Scope": scope, "Risk Level": risk})

        key = (role, "High-Risk" if risk.startswith("High-Risk") else ("Limited" if risk == "Limited Risk" else ""))
        if key in OBLIGATIONS_MAP:
            for ob in OBLIGATIONS_MAP[key]:
                obligations_rows.append({"System": sys_name, "Role": role, "Risk": risk, "Obligation": ob})

    summary_df = pd.DataFrame(rows)
    obligations_df = pd.DataFrame(obligations_rows) if obligations_rows else pd.DataFrame(columns=["System","Role","Risk","Obligation"])
    return summary_df, obligations_df
